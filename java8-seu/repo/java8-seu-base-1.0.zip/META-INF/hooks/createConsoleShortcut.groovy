import org.codehaus.groovy.scriptom.*

Scriptom.inApartment
{
	def wshShell = new ActiveXObject("WScript.Shell")
    def shortcut = wshShell.CreateShortcut("$seuHome\\console.lnk")
    shortcut.TargetPath = "$seuHome\\software\\start-console.bat"
    shortcut.WorkingDirectory = "$seuHome\\software"
	shortcut.Save()
}